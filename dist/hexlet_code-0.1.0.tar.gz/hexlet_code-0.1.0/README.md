### Hexlet tests and linter status:
[![Actions Status](https://github.com/urozhha/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/urozhha/python-project-49/actions)

<a href="https://codeclimate.com/github/urozhha/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/dcb971ed55c4afb7b2dd/maintainability" /></a>

Description: Try yourself in Brain Games!
Brain Games is math game, where you need to solve math problems like:

* Answer is number even or not ?
* Calculate math expression
* Answer is number even or not ?
* Find greatest common divisor of two numbers
* Find the missing element of an arithmetic progression



[![asciicast](https://asciinema.org/a/KzSRo4WLOlIzqm0gabNnjRIE6.svg)](https://asciinema.org/a/KzSRo4WLOlIzqm0gabNnjRIE6)

[![asciicast](https://asciinema.org/a/OqoIfH2IqKUH4BxclmaOHoMQ4.svg)](https://asciinema.org/a/OqoIfH2IqKUH4BxclmaOHoMQ4)

[![asciicast](https://asciinema.org/a/tEx4C2pPcs2OPvsOCZRNfnljB.svg)](https://asciinema.org/a/tEx4C2pPcs2OPvsOCZRNfnljB)

[![asciicast](https://asciinema.org/a/Qtlfs4LDB929856lMfRObAlx3.svg)](https://asciinema.org/a/Qtlfs4LDB929856lMfRObAlx3)

[![asciicast](https://asciinema.org/a/Hjo8PYvOgaBHh6EeejkADrhHC.svg)](https://asciinema.org/a/Hjo8PYvOgaBHh6EeejkADrhHC)
