### Hexlet tests and linter status:
[![Actions Status](https://github.com/urozhha/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/urozhha/python-project-49/actions)

<a href="https://codeclimate.com/github/urozhha/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/dcb971ed55c4afb7b2dd/maintainability" /></a>

<script id="asciicast-KzSRo4WLOlIzqm0gabNnjRIE6" src="https://asciinema.org/a/KzSRo4WLOlIzqm0gabNnjRIE6.js" async data-autoplay="true" data-size="big"></script>

[step 6 asciinema](https://asciinema.org/a/OqoIfH2IqKUH4BxclmaOHoMQ4)

[step 7 asciinema](https://asciinema.org/a/tEx4C2pPcs2OPvsOCZRNfnljB)

[step 8 asciinema](https://asciinema.org/a/Qtlfs4LDB929856lMfRObAlx3)

[step 9 asciinema](https://asciinema.org/a/Hjo8PYvOgaBHh6EeejkADrhHC)
