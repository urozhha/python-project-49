### Hexlet tests and linter status:
[![Actions Status](https://github.com/urozhha/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/urozhha/python-project-49/actions)