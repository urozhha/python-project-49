from brain_games.game_engine.greeting import name
from brain_games.game_engine.greeting import say_hello


def welcome_user():
    return say_hello(name)
