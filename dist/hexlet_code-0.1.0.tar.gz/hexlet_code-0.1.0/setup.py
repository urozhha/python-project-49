# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.game', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Short math game',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/urozhha/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/urozhha/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/urozhha/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/dcb971ed55c4afb7b2dd/maintainability" /></a>\n\n[step 5 asciinema](https://asciinema.org/a/KzSRo4WLOlIzqm0gabNnjRIE6)\n\n[step 6 asciinema](https://asciinema.org/a/OqoIfH2IqKUH4BxclmaOHoMQ4)\n\n[step 7 asciinema](https://asciinema.org/a/tEx4C2pPcs2OPvsOCZRNfnljB)\n\n[step 8 asciinema](https://asciinema.org/a/Qtlfs4LDB929856lMfRObAlx3)\n\n[step 9 asciinema](https://asciinema.org/a/Hjo8PYvOgaBHh6EeejkADrhHC)\n',
    'author': 'urozhha',
    'author_email': 'urozhha@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/urozhha/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
